﻿using FormulaAPI;
using PV178_HW02.App;
using PV178_HW02.Export;

UI ui = new UI();

ui.Start();